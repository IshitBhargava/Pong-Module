import pygame               # game processing library
import sys                  # provides various functions and variables that are used to manipulate different parts of the Python runtime      
import random               # For generating random numbers and choosing a random number from an array
import time                 # To wait. Used in various parts of the code such as waiting before exiting.
import sounddevice as sd    # To produce the audible buzz sound
import numpy as np          # It is needed to work with arrays
import tkinter as tk        # Needed for creating the input window
import textwrap             # Useless
import os

# Get the directory of the library file
library_dir = os.path.dirname(__file__)

# Construct the path to the image file
image_path = os.path.join(library_dir, "PONG_BG.png")

# Set colors
name = ""
pygame.init()    # Intialize PYgame

WHITE = (0, 0,0)
BLACK = (255, 255, 255)

screen = pygame.display.set_mode((800, 600))           # Create the window
pygame.display.set_caption("Pong and Cybersecurity Quiz")   # Give a title to the window

score = 0
                    # To save time
#rbb = None                         # To save time
#gbb = None                         # To save time
#bbb = None                         # To save time
#rb = None                           # To save time
#gb = None                          # To save time
#bb = None                          # To save time
ballsp = 15               # To save time
paddlesp = 20         # To save time
    

def runggame():
    global score, ertyu, rbb, gbb, bbb, rb, gb, bb, ballsp, paddlesp
    global name

    general_ins = "GENERAL INSTRUCTIONS = press the up arrow key to move the paddle up and the down arrow key to move the paddle down. Reply with \"real\" if the message is not fraud \n and with \"fake\" if the message is fake."   # General instructions message
    BUTTON_WIDTH = 220
    BUTTON_HEIGHT = 100
    

    # Messages
    messages = [
        "Dear [Name], your monthly account statement is now available for viewing. Please log in to your online banking account to access it. If you have any questions, feel free to contact our customer support team.",
        "Congratulations! You've won a lottery/prize worth $1,000,000! To claim your prize, please reply with your personal information and bank details",
        "This is the RBI. You have an outstanding tax debt, and legal action will be taken against you if it's not paid immediately. Please call this number to make a payment.",
        "Dear [Name], Congratulations! We are pleased to inform you that your loan application has been approved. Please review the terms and conditions provided in the attached document. If you have any questions, our loan specialists are available to assist you.",
        "Dear [Name], We have noticed unusual activity on your account. For your security, we have temporarily blocked access to your online banking. Please call our customer service hotline immediately to verify the activity and restore access to your account."
    ]
    score = 0                 # Define starting score as 0

    def ask_question(screen, font, name):
        global score                                                # Declare score as a global variable

        # Select a random message
        message = random.choice(messages).replace("[Name]", name)      # Select a random message
        print("Received message:", message)                            # print in shell

        # Determine the correct response
        if "lottery" in message.lower() or "prize" in message.lower():
            correct_response = "fake"                                 # Define 'correct response' as 'fake'
        elif "RBI" in message.lower() or "tax debt" in message.lower():
            correct_response = "fake"                                 # Define 'correct response' as 'fake'
        else:
            correct_response = "real"                                 # Define 'correct response' as 'real'

        if(ertyu == 1):
            screen.fill(BLACK)                                                                        # Clear the screen
        else:
            screen.blit(BLAC, (0, 0))
        
        question_text = bigfont.render("Identify if the message is real or fake: ", True, WHITE)  # Render the question
        screen.blit(question_text, (50, 50))                                                      # Print the question

        # Wrap the message text within a certain width
        wrapped_lines = textwrap.wrap(message, width=60)                                         # Wrap the message
        for i, line in enumerate(wrapped_lines):
            line_text = font.render(line, True, WHITE)                                           # Render the text
            screen.blit(line_text, (50, 100 + i * 30))                                           # Print the text

        # Draw the real and fake buttons
        real_button = pygame.Rect(WIDTH // 4 - BUTTON_WIDTH // 2, HEIGHT // 2, BUTTON_WIDTH, BUTTON_HEIGHT)     # Render 'real' button
        fake_button = pygame.Rect(3 * WIDTH // 4 - BUTTON_WIDTH // 2, HEIGHT // 2, BUTTON_WIDTH, BUTTON_HEIGHT) # Render 'fake' button
        pygame.draw.rect(screen, WHITE, real_button)                                                            # Print 'real' button
        pygame.draw.rect(screen, WHITE, fake_button)                                                            # Print 'fake' button

        # Render the button texts
        real_text = font.render("Real", True, BLACK)                       # Render button text
        fake_text = font.render("Fake", True, BLACK)                       # Render button text
        screen.blit(real_text, (real_button.x + 10, real_button.y + 10))   # Print button text
        screen.blit(fake_text, (fake_button.x + 10, fake_button.y + 10))   # Print button text

        pygame.display.flip()                                              # Refresh the display

        # Wait for player's response
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if real_button.collidepoint(event.pos):
                        response = "real"
                        #return response  # Return the player's response
                        if response == correct_response:
                            score += 5
                            print("You are correct!")
                            return response  # Return the player's response
                        else:
                            score -= 3
                            print("You are wrong. Game over!")
                            if(ertyu == 1): 
                                screen.fill(BLACK)
                            else:
                                screen.blit(BLAC, (0, 0))
                            score_text = bigfont.render("Sorry! You lost. Your cybersecurity score: " + str(score), True, WHITE)
                            screen.blit(score_text, (100, 300))
                            pygame.display.flip()
                            time.sleep(5)
                            pygame.quit()
                    elif fake_button.collidepoint(event.pos):
                        response = "fake"
                        #return response  # Return the player's response
                        if response == correct_response:
                            score += 5
                            print("You are correct!")
                            return response  # Return the player's response
                        else:
                            score -= 3
                            print("You are wrong. Game over!")
                            if(ertyu == 1):
                                screen.fill(BLACK)
                            else:
                                screen.blit(BLAC, (0, 0))
                            score_text = bigfont.render("Sorry! You lost. Your cybersecurity score: " + str(score), True, WHITE)
                            screen.blit(score_text, (100, 300))
                            pygame.display.flip()
                            time.sleep(5)
                            pygame.quit()

    def generate_buzz(duration_ms=10, frequency=440):
        sample_rate = 44100                                                                   # Sample rate in Hz
        t = np.linspace(0, duration_ms / 1000, int(sample_rate * duration_ms / 1000), False)  # Time array
        signal = np.sin(2 * np.pi * frequency * t)                                            # Generate a sine wave signal
        audio = (signal * 32767).astype(np.int16)                                             # Convert to 16-bit integer PCM
        sd.play(audio, samplerate=sample_rate)                                                # Play the audio


    WIDTH, HEIGHT = 800, 600   # Constant
    BALL_SPEED = ballsp        # Constants
    PADDLE_SPEED = paddlesp    # Constants

    screen.fill((0,0,0))


    if(ertyu == 1):
        WHITE = (rb, gb, bb)       # Colors
        BLACK = (rbb, gbb, bbb)
    else:
        BLAC = pygame.image.load(image_path) 
        #Blit the background image onto the screen
        screen.blit(BLAC, (0, 0))  # Position at (0, 0)
        WHITE = (rb, gb, bb)       # Colors
        BLACK = (rbb, gbb, bbb)


    ball = pygame.Rect(WIDTH // 2 - 15, HEIGHT // 2 - 15, 30, 30)  # Create game objects
    ball_speed_x = BALL_SPEED * random.choice([1, -1])             # Create game objects
    ball_speed_y = BALL_SPEED * random.choice([1, -1])             # Create game objects

    player_paddle = pygame.Rect(WIDTH - 50 - 20, HEIGHT // 2 - 50, 20, 100)  # Create game objects
    computer_paddle = pygame.Rect(30, HEIGHT // 2 - 50, 20, 100)             # Create game objects

    button_color = (255, 0, 0)                                               # Define button color (useless)
    button_rect = pygame.Rect(WIDTH // 2 - 50, 20, 100, 50)                  # Draw the button
    button_state = False                                                     # Define 'button_state' as 'False'

    font = pygame.font.Font(None, 24)        # Constant
    bigfont = pygame.font.Font(None, 35)     
    player_score = 0                         # Constant
    computer_score = 0                       # Constant

    print(general_ins)                       # Print the general instructions
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()                              # Close the tab
                sys.exit()                                 # Close 'sys'
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:                       # Left mouse button
                    if button_rect.collidepoint(event.pos):
                        button_state = True                 # Define 'button_state' as 'True'
                        
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:                       # Left mouse button
                    button_state = False                    # Define 'button_state' as 'False'
                    
        keys = pygame.key.get_pressed()                       # Detect key presses
        player_paddle.y -= keys[pygame.K_UP] * PADDLE_SPEED   # Move paddle up
        player_paddle.y += keys[pygame.K_DOWN] * PADDLE_SPEED # Move paddle down

        
        player_paddle.y = max(0, min(player_paddle.y, HEIGHT - player_paddle.height))  # Ensure player paddle stays within the valid range

        
        if ball.top < computer_paddle.top:
            computer_paddle.y -= PADDLE_SPEED   # Move the computer paddle
        elif ball.bottom > computer_paddle.bottom:
            computer_paddle.y += PADDLE_SPEED   # Move the computer paddle

        
        computer_paddle.y = max(0, min(computer_paddle.y, HEIGHT - computer_paddle.height))  # Ensure computer paddle stays within the valid range

        
        ball.x += ball_speed_x    # Move the ball
        ball.y += ball_speed_y    # Move the ball

        
        if ball.top <= 0 or ball.bottom >= HEIGHT:
            ball_speed_y = -ball_speed_y   # Ball collisions
            generate_buzz()                # Generate buzz

        if ball.colliderect(player_paddle) or ball.colliderect(computer_paddle):
            ball_speed_x = -ball_speed_x  # Ball collisions
            generate_buzz()               # Generate buzz

        if ball.left <= 0:
            player_score += 1                                             # Add one to the player's score
            print("Player Score:", player_score)                          # Print the score
            ball = pygame.Rect(WIDTH // 2 - 15, HEIGHT // 2 - 15, 30, 30) # Draw the ball again
            ball_speed_x = BALL_SPEED * random.choice([1, -1])            # Randomize ball spawning
            ball_speed_y = BALL_SPEED * random.choice([1, -1])            # Randomize ball's intial movement
        elif ball.right >= WIDTH:
            computer_score += 1                                           # Add one to the computer score
            print("Computer Score:", computer_score)                      # Print the computer score 
            ball = pygame.Rect(WIDTH // 2 - 15, HEIGHT // 2 - 15, 30, 30) # Draw the ball again
            ball_speed_x = BALL_SPEED * random.choice([1, -1])            # Randomize ball spawning
            ball_speed_y = BALL_SPEED * random.choice([1, -1])            # Randomize ball movement
            ask_question(screen, font, name)                              # Ask question
        if(ertyu == 1):
            screen.fill(BLACK)   # Clear the screen
        else:
            screen.blit(BLAC, (0, 0))
        pygame.draw.rect(screen, WHITE, player_paddle)      # Draw the player's paddle
        pygame.draw.rect(screen, WHITE, computer_paddle)    # Draw the computer's paddle
        pygame.draw.ellipse(screen, WHITE, ball)            # Draw the ball

        player_text = font.render(f"Player: {player_score}", True, WHITE)               # Render the message
        computer_text = font.render(f"Computer: {computer_score}", True, WHITE)         # Render the message
        screen.blit(player_text, (WIDTH - 150, 10))                                     # Print the message
        screen.blit(computer_text, (10, 10))                                            # Print the message

        cyber_score_text = font.render(f"Cyber Security Score: {score}", True, WHITE)                                       # Render the message
        screen.blit(cyber_score_text, (10, 30))                                                                             # Print the message (Adjust the position as needed)
        button_color = (BLACK) if button_state else (rb, gb, bb)                                                    # Change the button color if it is clicked
        pygame.draw.rect(screen, button_color, button_rect)                                                                 # Draw the button
        if(button_state == True):
            if(ertyu == 1):
                screen.fill(BLACK)
            else:       
                screen.blit(BLAC, (0, 0))                                                                             
            score_tet = font.render("Thanks for playing. Your cybersecurity score: " + str(score), True, (rb, gb, bb))      # Render the message    
            screen.blit(score_tet, (120, 300))                                                                              # Print the message
            pygame.display.flip()                                                                                           # Refresh the screen
            time.sleep(5)                                                                                                   # wait for 5 seconds
            pygame.quit()                                                                                                   # Close the pygame tab
            sys.exit()                                                                                                      # Close 'sys'
            break                                                                                                           # break the loop
        exit_text = font.render("Press to exit", True, (BLACK))        # Render the text
        exit_text_rect = exit_text.get_rect(center=button_rect.center) # Center the text on the button
        screen.blit(exit_text, exit_text_rect)                         # Print the text
        pygame.display.flip()                                          # Refresh the display
        pygame.time.delay(30)                    # Control the game's speed
        
rb = 0
gb = 0
bb = 0
rbb = 0
gbb = 0
bbb = 0
button_value = 0
        
def fill_screen_with_color():
    """
    Create sliders on the screen to adjust color values and return the updated values.

    Returns:
    - rb: Red brightness value for UI
    - gb: Green brightness value for UI
    - bb: Blue brightness value for UI
    - rbb: Red brightness value for background
    - gbb: Green brightness value for background
    - bbb: Blue brightness value for background
    """
    global rb, gb, bb, bbb, rbb, gbb, paddlesp, ballsp, button_value

    pygame.init()
    screen = pygame.display.set_mode((400, 600))
    running = True

    while running:
        screen.fill((255, 255, 255))  # Fill the screen with white

        # Draw sliders for UI color
        pygame.draw.rect(screen, (255, 0, 0), pygame.Rect(50, 50, 200, 20))   # Red slider
        pygame.draw.rect(screen, (0, 255, 0), pygame.Rect(50, 100, 200, 20))  # Green slider
        pygame.draw.rect(screen, (0, 0, 255), pygame.Rect(50, 150, 200, 20))  # Blue slider

        # Draw sliders for background color
        pygame.draw.rect(screen, (255, 0, 0), pygame.Rect(50, 200, 200, 20)) # Red slider
        pygame.draw.rect(screen, (0, 255, 0), pygame.Rect(50, 250, 200, 20)) # Green slider
        pygame.draw.rect(screen, (0, 0, 255), pygame.Rect(50, 300, 200, 20)) # Blue slider

        # Draw slider indicators for UI color
        pygame.draw.rect(screen, (rb, 0, 0), pygame.Rect(50 + rb - 5, 45, 10, 30))   # Red indicator
        pygame.draw.rect(screen, (0, gb, 0), pygame.Rect(50 + gb - 5, 95, 10, 30))   # Green indicator
        pygame.draw.rect(screen, (0, 0, bb), pygame.Rect(50 + bb - 5, 145, 10, 30))  # Blue indicator

        # Draw slider indicators for background color
        pygame.draw.rect(screen, (rbb, 0, 0), pygame.Rect(50 + rbb - 5, 195, 10, 30)) # Red indicator
        pygame.draw.rect(screen, (0, gbb, 0), pygame.Rect(50 + gbb - 5, 245, 10, 30)) # Green indicator
        pygame.draw.rect(screen, (0, 0, bbb), pygame.Rect(50 + bbb - 5, 295, 10, 30)) # Blue indicator
        
        # Draw sliders for background color
        pygame.draw.rect(screen, (255, 255, 0), pygame.Rect(50, 400, 200, 20)) # Red slider
        pygame.draw.rect(screen, (0, 255, 255), pygame.Rect(50, 350, 200, 20)) # Green slider

        #Draw slider indicators for background color
        pygame.draw.rect(screen, (paddlesp, 0, 0), pygame.Rect(50 + paddlesp - 5, 395, 10, 30)) # Red indicator
        pygame.draw.rect(screen, (0, ballsp, 0), pygame.Rect(50 + ballsp - 5, 345, 10, 30)) # Green indicator



        # Draw close button
        pygame.draw.rect(screen, (255, 0, 0), pygame.Rect(50, 550, 300, 30)) # Close button
        font = pygame.font.Font(None, 36)
        close_text = font.render("Close", True, (255, 255, 255))
        screen.blit(close_text, (170, 550))
        
        # Draw normal button
        pygame.draw.rect(screen, (0, 0, 0), pygame.Rect(50, 500, 100, 30))  # Button
        font = pygame.font.Font(None, 24)
        button_text = font.render("BG Choice", True, (255, 255, 255))
        screen.blit(button_text, (60, 505))

        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left mouse button
                    mouse_x, mouse_y = pygame.mouse.get_pos()
                    if 50 <= mouse_x <= 150 and 500 <= mouse_y <= 530:
                        button_clicked = True
                        button_value += 1
                    elif 50 <= mouse_x <= 350 and 550 <= mouse_y <= 580: # Close button clicked
                        running = False
                    elif 50 <= mouse_y <= 70: # Red slider clicked
                        rb = min(max(mouse_x - 50, 0), 300)
                    elif 100 <= mouse_y <= 120: # Green slider clicked
                        gb = min(max(mouse_x - 50, 0), 300)
                    elif 150 <= mouse_y <= 170: # Blue slider clicked
                        bb = min(max(mouse_x - 50, 0), 300)
                    elif 200 <= mouse_y <= 220: # Red background slider clicked
                        rbb = min(max(mouse_x - 50, 0), 300)
                    elif 250 <= mouse_y <= 270: # Green background slider clicked
                        gbb = min(max(mouse_x - 50, 0), 300)
                    elif 300 <= mouse_y <= 320: # Blue background slider clicked
                        bbb = min(max(mouse_x - 50, 0), 300)
                    elif 350 <= mouse_y <= 370: # Blue background slider clicked
                        ballsp = min(max(mouse_x - 50, 0), 15)
                    elif 400 <= mouse_y <= 420: # Blue background slider clicked
                        paddlesp = min(max(mouse_x - 50, 0), 20)

        # Check for exit condition
        if not running:
            screen = pygame.display.set_mode((800, 600))
            screen.fill((0,0,0))



# Variable to store the button state
button_state = None
bla = (0, 0, 0)
whi = (255, 255, 255)
r = (255, 0, 0)
g = (0, 255, 0)
b = (0, 0, 255)
# Set button dimensions
BUTTON_WIDTH = 200
BUTTON_HEIGHT = 100
screen_width = 800
screen_height = 800
xcm = 0
button_titles = ["Play", "Settings","Quit"]
# Main loop
running = True
while running:
    # Fill the screen with black color
    screen.fill(bla)

    # Draw buttons
    button1_rect = pygame.Rect(100, 200, BUTTON_WIDTH, BUTTON_HEIGHT)
    pygame.draw.rect(screen, r, button1_rect)
    font = pygame.font.Font(None, 36)
    text = font.render(button_titles[0], True, whi)
    text_rect = text.get_rect(center=button1_rect.center)
    screen.blit(text, text_rect)

    button2_rect = pygame.Rect(300, 200, BUTTON_WIDTH, BUTTON_HEIGHT)
    pygame.draw.rect(screen, g, button2_rect)
    text = font.render(button_titles[1], True, whi)
    text_rect = text.get_rect(center=button2_rect.center)
    screen.blit(text, text_rect)

    button3_rect = pygame.Rect(500, 200, BUTTON_WIDTH, BUTTON_HEIGHT)
    pygame.draw.rect(screen, b, button3_rect)
    text = font.render(button_titles[2], True, whi)
    text_rect = text.get_rect(center=button3_rect.center)
    screen.blit(text, text_rect)
    
    # Draw text
    input_text = font.render("Enter Your Name: " + name, True, BLACK)
    input_rect = input_text.get_rect(center=(screen_width // 2, screen_height // 2))
    screen.blit(input_text, input_rect)

    # Event handling
        


    # Get mouse position
    mouse_x, mouse_y = pygame.mouse.get_pos()
    mouse_pos = pygame.mouse.get_pos()

    # Check for button clicks
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if button1_rect.collidepoint(mouse_pos):
                #button_state = 0
                if(xcm == 0):
                    ertyu = 0
                    rb = 255
                    gb = 255
                    bb = 255
                runggame()
            elif button2_rect.collidepoint(mouse_pos):
                #button_state = 1
                fill_screen_with_color()
                if(((button_value % 2) == 0) or (button_value == 0)):
                    ertyu = 0
                else: 
                    ertyu = 1
                xcm = 1
                print("Color values:", rb, gb, bb, rbb, gbb, bbb, paddlesp, ballsp,button_value)
            elif button3_rect.collidepoint(mouse_pos):
                #button_state = 2
                pygame.quit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                # If Enter is pressed, print the name and reset it
                print("Name entered:", name)
            elif event.key == pygame.K_BACKSPACE:
                # If Backspace is pressed, remove the last character from the name
                name = name[:-1]
            else:
                # Otherwise, add the character to the name
                name += event.unicode
    
    # Update the display
    pygame.display.flip()  # Quit Pygame
pygame.quit()

# Print the final button state
print("Button state:", button_state)
