from setuptools import setup, find_packages

setup(
    name='pong',
    version='1.0',
    packages=find_packages(),
    install_requires=['pygame', 'numpy', 'sounddevice','tkinter','os'],
    author='Ishit Bhargava',
    author_email='ishit.bh@gmail.com',
    description='A Python package for playing the Cyberpong game',
    url='https://github.com/ishitbhargava/',
)
